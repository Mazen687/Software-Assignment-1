import java.util.Scanner;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
//Calc BMR  معدل الحرق
//Calc BMI
//Calc TDEE
public class Main {

    public static void main(String[]args) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        String currentTime = now.format(formatter);


        double TDEE;//BMR* Activity factor
        double BMR = 0;
        double BMI;
        int age ;
        String name;
        double weight ;
        double height ;
        System.out.printf("%n please enter your gender (female or male) ");
        Scanner input = new Scanner(System.in);
        String gender = input.next();

        while(!gender.equals("female") && !gender.equals("male")){
            System.out.println("please check your gender!");
             gender = input.next();
      }
            System.out.println("enter your name");
            name = input.next();
            System.out.println("enter your age");
            age = input.nextInt();
            System.out.println("enter your weight(Kg)");
            weight = input.nextInt();
            System.out.println("enter your height(cm)");
            height = input.nextInt();

            if (gender.equals("female")) {
                BMR = (10 * weight) + (6.25 * height) - (5 * age) - 161;
            } else {
                BMR = (10 * weight) + (6.25 * height) - (5 * age) + 5;
            }


        System.out.printf("============welcome %s===========%nyour BMR = %.1f%n", name, BMR);
        System.out.printf("choose your Activity level from 1 to 5 :%n=============================%n 1.Sedentary(no movement)%n=============================%n 2.Light(training 1-3 days/week)%n=============================%n 3.Moderate(training 3-5 days/week)%n=============================%n 4.Very Active(training 6-7 days/week)%n=============================%n 5.Super Active(hard word and training 3-5 days/week)%n");
        int level = input.nextInt();
        //1 =>1.2
        //2=>1.375
        double[] array = {1.2, 1.375, 1.55, 1.725, 1.9};
        TDEE=array[level - 1] * BMR;
        BMI=weight/((height/100)*(height/100));//in meters
        if(BMI<18.5){
            System.out.println("-----You are Underweight need to increase your calories-----");
        }else if(BMI>=18.5 &&BMI<=24.9){
            System.out.println("-----You are Normal-----");
        }else if(BMI>=25 &&BMI<=29.9){
            System.out.println("-----You are Overweight need to follow calorie deficit-----");
        }else if(BMI>=30 &&BMI<=34.9){
            System.out.println("-----You are Obese Class I need to follow calorie deficit -----");
        }else if(BMI>=35 &&BMI<=39.9){
            System.out.println("-----You are Obese Class II need to follow calorie deficit-----");
        }
        else if(BMI>=40){
            System.out.println("-----You are Obese Class III need follow calorie deficit-----");
        }

        System.out.printf("you need to eat %.2f calories/day to keep your weight static", TDEE);

//=================================================================================================================
        //File handling
        try {
                FileWriter fileWriter = new FileWriter("history.txt", true);
                PrintWriter printWriter = new PrintWriter(fileWriter);
                printWriter.println("=== " + currentTime + " ===");
                printWriter.println("Name: " + name);
                printWriter.println("Gender: " + gender);
                printWriter.println("Age: " + age + ", Weight: " + weight + "kg, Height: " + height + "cm");
                printWriter.println("BMR: " + String.format("%.2f", BMR) + " calories/day");
                printWriter.println("BMI:"+ BMI);
                printWriter.println("--------------------------------");

                printWriter.close();
            } catch (Exception e) {
                System.out.println("wrong in saving file"+e.getLocalizedMessage());
            }
            input.close();
    }
}

